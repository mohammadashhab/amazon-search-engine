from re import sub
from nltk import word_tokenize, pos_tag, RegexpParser, corpus, FreqDist, islice
import matplotlib.pylab as plt

"""
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Pre-Processing ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
"""

# Positive & Negative adjectives as set.
positiveAdj = set(line.strip().lower() for line in open('positive adj'))
negativeAdj = set(line.strip().lower() for line in open('negative adj'))

# TAGS to fine all requested Part Of Speach.
chunk = r"""TAG: {((<RB\W?>*|<RBR\W?>*|<RBS\W?>*)(<JJ\W?>+|<JJR\W?>+|<JJS\W?>+)(<NN\w*>|<NNS\w*>))|"""
chunk += """((<NN\w*>|<NNS\w*>)<RB\W?>*<RBR\W?>*<RBS\W?>*(<JJ\W?>+|<JJR\W?>+|<JJS\W?>+))|"""
chunk += """((<RB\W?>+|<RBR\W?>+|<RBS\W?>+)(<VB\w*>|<VBD\w*>|<VBN\w*>))|(<VB\W?>|<VBD\W?>|"""
chunk += """<VBN\W?>|<VBZ\W?>|<VBP\W?>)((<RB\W?>+|<RBR\W?>+|<RBS\W?>+)|((<NN\w*>+|<NNS\w*>+)(<JJ\W?>+|<JJR\W?>+|<JJS\W?>+)))}"""


def finalStopWords():
    """
    Stop words to remove from the text.
    :return: set of all stop words we need.
    """
    stopWords = corpus.stopwords.words('english')
    for stopword in ['it', "it's", 'its', "don't", 'do', 'not', 'to']:
        stopWords.remove(stopword)
    return set(stopWords)


def checkTag(x):
    for i in range(len(x)):
        if len(x[i][0]) <= 1:
            return False
    return True


def scoreDict(lst):
    """
    Caculate the score of each sentence in the given list.(1 if the sentence if positive and -1 if the sentence is
    negative and 0 otherwise).
    :param lst: list of sentences
    :return: dict of the sentences and their score.
    """
    res = dict()
    for sentence in lst:
        words = word_tokenize(sentence)
        result = 1
        score = 0
        for word in words:
            if word == "not":
                result = -1
                continue
            elif word in positiveAdj:
                result *= 1
            elif word in negativeAdj:
                result *= -1
            else:
                result = 0
            score += result
            result = 1
        res[sentence] = score
    return res


stopWords = finalStopWords()


def POStagging(text):
    """
    Do POStaging of the given text and calculate the score of each sentence (1 if the sentence if positive and
    -1 if the sentence is negative and 0 otherwise).
    :param text: string to do POStaging to in.
    :return: dict of all the sentences and their score and False otherwise.
    """
    subString = ''
    res = []

    words = word_tokenize(sub("n't", ' not', text))
    filteredSentence = ' '.join([w for w in words if not w in stopWords])
    if len(filteredSentence) > 0:
        finalTree = RegexpParser(chunk).parse(pos_tag(word_tokenize(filteredSentence)))

        """
        we go over the decision tree in order to find all the appropriate tags.
        """
        for subtree in finalTree.subtrees(filter=lambda t: t.label() == 'TAG'):
            if checkTag(subtree):
                for i in range(len(subtree)):
                    subString += subtree[i][0]
                    if not i == len(subtree) - 1:
                        subString += ' '
                res.append(subString)
                subString = ''

        return scoreDict(res)
    return False


"""
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Tokenize the reviews of all category ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
"""


def parser(file):
    """
    Gets the file and filters it.
    Where anything that isn't a letter or "_" or a character of length 1 into a space,and then each capital letter is
    transformed into a small one and then returns the result as a file.
    """
    parsedFile = sub('[_]', '', sub('[^\w]', ' ', file).lower())
    parsedFile = ' '.join([word for word in parsedFile.split() if len(word) > 1 and word.isalpha()])
    return parsedFile


def plotGraph(tokenizeText, name):
    # Plot log frequency vs log rank.
    plt.title(name)
    plt.xlabel('log rank')
    plt.ylabel('log frequency')
    plt.plot(*zip(*sorted(tokenizeText.items())))
    plt.show()


def tokenize(str, stopWords, name):
    filteredFile = parser(str)

    # Tokenizes the file, and calculates the number we got for each token as dictionary.
    fd = FreqDist(word_tokenize(filteredFile))

    # Sort the dictionary by  values (the number of appearances for each key 'token').
    fd = {k: v for k, v in sorted(fd.items(), key=lambda item: item[1], reverse=True)}

    for i in stopWords:
        if i in fd.keys():
            del fd[i]

    count = 1
    tokenizeText = dict()
    for key, val in fd.items():
        tokenizeText[plt.log(count)] = plt.log(val)
        count += 1

    # Get the top 100 tokens.
    tokens = list(islice(fd.items(), 100))

    plotGraph(tokenizeText, name)

    return tokens


def getAllCategoryTokens(categories, outputPath):
    """
    Get all tokens in each category by all Products reviews.
    :param categories: Json file saved in it all the categories and the Products objects that relevant to ot.
    :param outputPath: .txt file to write all the tokens to it.
    """
    stopWords = corpus.stopwords.words('english')
    categories.getAllRewiews()
    with open(outputPath, 'w') as input:
        for cat, reviews in categories.dictOfAllRewiews.items():
            input.write(cat + '\n')
            input.write('tokens:\n')
            for i in tokenize(reviews, stopWords, cat):
                input.write(' '.join(str(s) for s in i) + '\n')
            input.write('\n')

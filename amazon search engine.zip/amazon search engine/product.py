SUB_CATAGORIES = ["Keyboard & Mouse Combos", "Camera", "Tablets",
                  "Speakers", "Headphones", "Vehicle GPS", "Memory Cards", "Modems"]


class ReviewsAndRatings:
    def __init__(self, rating, review, scoreDict):
        self.rating = rating
        self.review = review
        self.reviewScore = scoreDict  # Dict that contains all the phrases that fits with the review with its scores.


class Product:
    def __init__(self, name, number, images, categories):
        self.overall = 0
        self.numOfReviews = 0
        self.score = 0
        self.name = name
        self.number = number
        self.images = images
        self.categories = categories
        self.listOfReviewsAndRatings = list()

    def addReview(self, rating, review, scoreDict):
        if scoreDict != False:
            self.listOfReviewsAndRatings.append(ReviewsAndRatings(rating, review, scoreDict))
            self.numOfReviews += 1

    def setRating(self):
        self.overall = sum(
            [i.rating for i in self.listOfReviewsAndRatings]) / self.numOfReviews


class Categories:
    def __init__(self):
        self.categories = dict()
        self.dictOfAllRewiews = dict()
        self.productsNumbers = set()  # Set of all products numbers that we add until now.

    def addCatagory(self, category):
        """
        Create Product object and add it to the category it agree with.
        Notice: All the categories in the metadata for electronics start with Electronics so we start with the second element.
        :param category: One dict from the metadata.json file that describe specific product.
        """
        for i in category['category'][1:]:
            if i in SUB_CATAGORIES:
                if i not in self.categories.keys():
                    self.categories[i] = list()
                elif 'title' in category.keys() and 'image' in category.keys() and len(self.categories[i]) <= 10000:
                    newProduct = Product(category['title'], category['asin'], category['image'],
                                         category['category'][1:])
                    self.categories[i].append(newProduct)
                    self.productsNumbers.add(category['asin'])

    def getAllRewiews(self):
        for cat, products in self.categories.items():
            self.dictOfAllRewiews[cat] = ''
            for product in products:
                for review in product.listOfReviewsAndRatings:
                    self.dictOfAllRewiews[cat] += (' ' + review.review)

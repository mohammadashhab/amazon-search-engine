import tkinter as tk
from tkinter import messagebox
from BestProducts import findTheBestProducts
from PIL import Image, ImageTk
from io import BytesIO
import urllib.request


class SampleApp(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.title("Amazon Reviews Search Engine")
        self.geometry('500x600+1400+300')
        self._frame = None
        self.resizable(0, 0)
        self._image = tk.PhotoImage(file="amazon2.png")
        self.switch_frame(StartPage)

    def switch_frame(self, frame_class, i=0, prev=0, finalProducts=None):
        if i == 0:
            new_frame = frame_class(self)
        else:
            new_frame = frame_class(self, prev, finalProducts)
            self.title("Search Results")
            self.geometry('1500x800+40+40')
            self._frame = new_frame
            self._frame.place(x=0, y=0)
            tk.Label(self, image=self._image).place(x=600, y=20)
            self._frame.place(x=0, y=0, width=1500, height=800)
            tk.Button(self, text="Exit.", command=lambda: quit()).place(bordermode=tk.OUTSIDE,
                                                                        height=50, width=150, x=650,
                                                                        y=700)
            return
        self.title("Amazon Reviews Search Engine")
        self.geometry('500x600-300+100')
        if self._frame is not None:
            self._frame.destroy()
        self._frame = new_frame
        self._frame.pack()
        tk.Label(self, image=self._image).place(x=100, y=20)
        self._frame.place(x=0, y=0, width=500, height=600)
        tk.Button(self, text="Exit.", command=lambda: quit()).place(bordermode=tk.OUTSIDE,
                                                                    height=50, width=150, x=175,
                                                                    y=500)


class StartPage(tk.Frame):
    def __init__(self, master):
        tk.Frame.__init__(self, master)
        self.gui()

    def gui(self):
        tk.Label(self, text="Select One Category", font=('Helvetica', 12, "bold")).place(x=175, y=160)

        tk.Button(self, text="Keyboard & Mouse", command=lambda: self.master.switch_frame(KeyboardAndMouse)) \
            .place(bordermode=tk.OUTSIDE, height=50, width=150, x=75, y=200)
        tk.Button(self, text="Camera & Accessories", command=lambda: self.master.switch_frame(Camera)). \
            place(bordermode=tk.OUTSIDE, height=50, width=150, x=275, y=200)

        tk.Button(self, text="Tablets", command=lambda: self.master.switch_frame(Tablets)) \
            .place(bordermode=tk.OUTSIDE, height=50, width=150, x=75, y=275)

        tk.Button(self, text="Speakers", command=lambda: self.master.switch_frame(Speakers)) \
            .place(bordermode=tk.OUTSIDE, height=50, width=150, x=275, y=275)

        tk.Button(self, text="Headphones", command=lambda: self.master.switch_frame(Headphones)) \
            .place(bordermode=tk.OUTSIDE, height=50, width=150, x=75, y=350)

        tk.Button(self, text="Vehicle GPS", command=lambda: self.master.switch_frame(VehicleGPS)) \
            .place(bordermode=tk.OUTSIDE, height=50, width=150, x=275, y=350)

        tk.Button(self, text="Memory Cards", command=lambda: self.master.switch_frame(MemoryCards)) \
            .place(bordermode=tk.OUTSIDE, height=50, width=150, x=75, y=425)
        tk.Button(self, text="Modems", command=lambda: self.master.switch_frame(Modems)) \
            .place(bordermode=tk.OUTSIDE, height=50, width=150, x=275, y=425)

        tk.Button(self, text="Info", fg="red", command=lambda: self.info()).place(bordermode=tk.OUTSIDE,
                                                                                  height=30, width=70, x=210,
                                                                                  y=560)

    def info(self):
        messagebox.showinfo("Amazon Reviews Search Engine", "This program searches for products according to the"
                        " people reviews, We let you chose the features that you want in the product and we search"
                        " in the reviews for you, And find the best products that satisfy your features in "
                                        "a positive way according to the people opinion :)")


class Page(tk.Frame):
    def __init__(self, master, category, allOptions, curr):
        tk.Frame.__init__(self, master)
        tk.Frame.configure(self)
        tk.Button(self, text="Go back to start page", command=lambda: master.switch_frame(StartPage)). \
            place(bordermode=tk.OUTSIDE, height=50, width=150, x=75, y=420)
        tk.Button(self, text="Get Result", command=lambda: self.getResult(master)). \
            place(bordermode=tk.OUTSIDE, height=50, width=150, x=280, y=420)
        tk.Label(self, text="Select one or more Search Words:", font=('Helvetica', 12, "bold")).place(x=130, y=160)
        self._current = curr
        self._allVars = []
        self.getVars()
        self._allOptions = allOptions
        self._selections = []
        self._words = []
        self._category = category
        self.gui()

    def gui(self):
        font = ('Helvetica', 11, "bold")
        tk.Checkbutton(self, text=self._allOptions[0], font=font,
                       command=lambda: self.fill_options(self._allVars[0]), variable=self._allVars[0]).place(x=60,
                                                                                                             y=200)
        tk.Checkbutton(self, text=self._allOptions[1], font=font,
                       command=lambda: self.fill_options(self._allVars[1]), variable=self._allVars[1]).place(x=160,
                                                                                                             y=200)
        tk.Checkbutton(self, text=self._allOptions[2], font=font,
                       command=lambda: self.fill_options(self._allVars[2]), variable=self._allVars[2]).place(x=260,
                                                                                                             y=200)
        tk.Checkbutton(self, text=self._allOptions[3], font=font,
                       command=lambda: self.fill_options(self._allVars[3]), variable=self._allVars[3]).place(x=360,
                                                                                                             y=200)
        tk.Checkbutton(self, text=self._allOptions[4], font=font,
                       command=lambda: self.fill_options(self._allVars[4]), variable=self._allVars[4]).place(x=60,
                                                                                                             y=240)
        tk.Checkbutton(self, text=self._allOptions[5], font=font,
                       command=lambda: self.fill_options(self._allVars[5]), variable=self._allVars[5]).place(x=160,
                                                                                                             y=240)
        tk.Checkbutton(self, text=self._allOptions[6], font=font,
                       command=lambda: self.fill_options(self._allVars[6]), variable=self._allVars[6]).place(x=260,
                                                                                                             y=240)
        tk.Checkbutton(self, text=self._allOptions[7], font=font
                       , command=lambda: self.fill_options(self._allVars[7]), variable=self._allVars[7]).place(x=360,
                                                                                                               y=240)
        tk.Checkbutton(self, text=self._allOptions[8], font=font,
                       command=lambda: self.fill_options(self._allVars[8]), variable=self._allVars[8]).place(x=60,
                                                                                                             y=280)
        tk.Checkbutton(self, text=self._allOptions[9], font=font,
                       command=lambda: self.fill_options(self._allVars[9]), variable=self._allVars[9]).place(x=160,
                                                                                                             y=280)
        tk.Checkbutton(self, text=self._allOptions[10], font=font,
                       command=lambda: self.fill_options(self._allVars[10]), variable=self._allVars[10]).place(x=260,
                                                                                                               y=280)
        tk.Checkbutton(self, text=self._allOptions[11], font=('Helvetica', 11, "bold"),
                       command=lambda: self.fill_options(self._allVars[11]), variable=self._allVars[12]).place(x=360,
                                                                                                               y=280)
        tk.Label(self, text="Or type other and press the enter button:"
                 , font=('Helvetica', 12, "bold")).place(x=115, y=320)
        entry = tk.Entry(self)
        entry.place(x=150, y=350)
        tk.Button(self, text="enter", command=lambda: self.checkInput(entry)). \
            place(bordermode=tk.OUTSIDE, height=30, width=45, x=330, y=348)

        tk.Label(self, text="please enter one or more words (up to three) in english separated by ','"
                 , font=('Helvetica', 8, "bold")).place(x=90, y=390)

    def getVars(self):
        for option in self._allOptions:
            var = tk.IntVar(name=option)
            self._allVars.append(var)

    def fill_options(self, option):
        if option._name in self._selections:
            if option.get() == 0:
                self._selections.remove(option._name)
        else:
            self._selections.append(option._name)

    def checkInput(self, e):
        if len(self._selections) > 0:
            messagebox.showinfo("Wrong Input", "please remove your selects if you want to type!")
            return 0
        words = (e.get()).split(",")
        if len(words) > 3 or len(words) == 0 or (len(words) == 1 and len(words[0]) == 0):
            messagebox.showinfo("Wrong Input", "Please select up to 3 words!")
            return 0
        for word in words:
            for letter in word:
                if not letter.isalpha() and letter != " ":
                    messagebox.showinfo("Wrong Input", "Please enter english words (a-z, A-Z) separated with ','!")
                    return 0
        self._words = [word.lower() for word in words]

    def getResult(self, master):
        if len(self._selections) > 0 and len(self._words) > 0:
            messagebox.showinfo("Wrong Input", "please remove your selects if you want to type!")
            return 0
        elif len(self._selections) == 0 and len(self._words) == 0:
            messagebox.showinfo("Wrong Input", "Please select from the options at least one or type up to 3 options.")
            return 0
        final = list(set(self._selections + self._words))
        self.reset()
        products = findTheBestProducts(self._category, final)
        if len(products) == 0:
            messagebox.showinfo("No Results", "We couldn't find any result that suits your search words :( , Please "
                                              "try to enter different search words or pick from the given ones.")
            return
        master.switch_frame(ResultPage, i=1, prev=self._current, finalProducts=products)

    def reset(self):
        self._selections = []
        self._words = []
        for var in self._allVars:
            var.set(0)


class KeyboardAndMouse(Page):
    _allOptions = ["keys", "wireless", "battery", "button", "light", "bluetooth", "typing",
                   "quality", "size", "software", "receiver", "comfortable", ""]
    _category = "Keyboard & Mouse Combos"

    def __init__(self, master):
        Page.__init__(self, master, self._category, self._allOptions, KeyboardAndMouse)
        self.master = master


class Camera(Page):
    _allOptions = ["adapter", "battery", "fast", "screen", "charging", "power", "resolution", "size",
                   "quality", "photos", "hours", "lense", ""]
    _category = "Camera"

    def __init__(self, master):
        Page.__init__(self, master, self._category, self._allOptions, Camera)
        self.master = master


class Headphones(Page):
    _allOptions = ["sound", "quality", "noise", "comfortable", "battery", "clear", "bluetooth", "size",
                   "bass", "fit", "hours", "excellent ", ""]
    _category = "Headphones"

    def __init__(self, master):
        Page.__init__(self, master, self._category, self._allOptions, Headphones)
        self.master = master


class VehicleGPS(Page):
    _allOptions = ["easy", "clear", "battery", "voice", "smart", "size", "price", "display",
                   "quality", "system", "excellent", "calculate", ""]
    _category = "Vehicle GPS"

    def __init__(self, master):
        Page.__init__(self, master, self._category, self._allOptions, VehicleGPS)
        self.master = master


class Speakers(Page):
    _allOptions = ["theater", "smooth", "bass", "quality", "battery", "clear", "bluetooth", "size",
                   "loud", "range", "setup", "small ", ""]
    _category = "Speakers"

    def __init__(self, master):
        Page.__init__(self, master, self._category, self._allOptions, Speakers)
        self.master = master


class Modems(Page):
    _allOptions = ["adapter", "range", "wireless", "wifi", "setup", "signal", "fast", "easy",
                   "quality", "comcast", "service", "excellent", ""]
    _category = "Modems"

    def __init__(self, master):
        Page.__init__(self, master, self._category, self._allOptions, Modems)
        self.master = master


class MemoryCards(Page):
    _allOptions = ["speed", "temperature", "fast", "quality", "storage", "digital", "micro", "size",
                   "sd", "photos", "space", "transfer perfectly", ""]
    _category = "Memory Cards"

    def __init__(self, master):
        Page.__init__(self, master, self._category, self._allOptions, MemoryCards)
        self.master = master


class Tablets(Page):
    _allOptions = ["screen", "resolution", "battery", "fast", "charge", "camera", "touch", "kids",
                   "light", "photos", "keyboard", "great", ""]
    _category = "Tablets"

    def __init__(self, master):
        Page.__init__(self, master, self._category, self._allOptions, Tablets)
        self.master = master


class ResultPage(tk.Frame):
    def __init__(self, master, prev, products):
        tk.Frame.__init__(self, master)
        tk.Frame.configure(self)
        self.prev = prev
        self.products = products
        tk.Button(self, text="Go back to start page", command=lambda: master.switch_frame(StartPage)). \
            place(bordermode=tk.OUTSIDE, height=50, width=150, x=450, y=700)
        tk.Button(self, text="Search page", command=lambda: master.switch_frame(prev)). \
            place(bordermode=tk.OUTSIDE, height=50, width=150, x=850, y=700)
        self._images = []
        self.getImages()
        self.placeImages()
        self.gui()

    def gui(self):
        font = ('Helvetica', 11, "bold")
        tk.Label(self, text="Top 3 products that may satisfy your search according to the faetures you have chosen:"
                 , font=('Helvetica', 12, "bold")).place(x=400, y=190)
        tk.Label(self, text="Product asin: ", font=font, fg="red").place(x=20, y=220)
        tk.Label(self, text=self.products[0].number, font=font).place(x=125, y=220)
        tk.Label(self, text="Overall rating: ", font=font, fg="red").place(x=280, y=220)
        tk.Label(self, text=str(self.products[0].overall)[:3] + "/5", font=font).place(x=387, y=220)

        tk.Label(self, text="Product asin: ", font=font, fg="red").place(x=500, y=220)
        tk.Label(self, text=self.products[1].number, font=font).place(x=605, y=220)
        tk.Label(self, text="Overall rating: ", font=font, fg="red").place(x=760, y=220)
        tk.Label(self, text=str(self.products[1].overall)[:3] + "/5", font=font).place(x=867, y=220)

        tk.Label(self, text="Product asin: ", font=font, fg="red").place(x=980, y=220)
        tk.Label(self, text=self.products[2].number, font=font).place(x=1085, y=220)
        tk.Label(self, text="Overall rating: ", font=font, fg="red").place(x=1240, y=220)
        tk.Label(self, text=str(self.products[2].overall)[:3] + "/5", font=font).place(x=1347, y=220)

        font2 = ('Helvetica', 10, "bold")

        if len(self.products) > 3:
            other = self.products[3].number + ", " + self.products[4].number + ", " + self.products[4].number
        else:
            other = ''

        tk.Label(self, font=font2, text="Other products: ", fg="red").place(x=20, y=650)
        tk.Label(self, text=other, font=font2).place(x=130, y=650)

    def getImages(self):
        for i in range(3):
            url = self.products[i].images[0]
            subStr = ["._SS40_", "._SS36_", "._SX38_SY50_CR,0,0,38,50_", "._SR38,50_"]
            for j in subStr:
                if j in url:
                    url = url.replace(j, "._SS360_")
            raw_data = urllib.request.urlopen(url).read()
            im = Image.open(BytesIO(raw_data))
            img = ImageTk.PhotoImage(im)
            self._images.append(img)

    def placeImages(self):
        tk.Label(self, image=self._images[0]).place(x=50, y=240)
        tk.Label(self, image=self._images[1]).place(x=500, y=240)
        tk.Label(self, image=self._images[2]).place(x=1000, y=240)


def main():
    app = SampleApp()
    app.mainloop()


if __name__ == "__main__":
    main()

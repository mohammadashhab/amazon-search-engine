import json
from TextMining import *
from product import Categories
from BestProducts import *

def buildProducts(path):
    catagories = Categories()
    with open(path, "r") as f:
        for jsonObj in f:
            objectDict = json.loads(jsonObj)
            catagories.addCatagory(objectDict)
    return catagories


def getReviews(reviewsPath, produtsNums):
    reviews = dict()
    with open(reviewsPath, "r") as f:
        for jsonObj in f:
            objectDict = json.loads(jsonObj)
            if objectDict["asin"] not in reviews.keys() and objectDict["asin"] in produtsNums:
                reviews[objectDict["asin"]] = list()
            if "reviewText" in objectDict.keys() and objectDict["asin"] in produtsNums and \
                    "overall" in objectDict.keys() and len(reviews[objectDict["asin"]]) <= 40:
                reviews[objectDict["asin"]].append([objectDict["overall"], objectDict["reviewText"]])
    return reviews


def updateReviewsAndRating(products, reviews):
    count = 0
    for products in products.categories.values():
        for product in products:
            if product.number in reviews.keys():
                for h in reviews[product.number]:
                    count += 1
                    if count % 50000 == 0:
                        print(count)
                    product.addReview(h[0], h[1], POStagging(h[1]))
                if product.numOfReviews > 0:
                    product.setRating()


if __name__ == "__main__":
    # Build the Categories.
    allProducts = buildProducts("meta_Electronics.json")
    reviews = getReviews("Electronics.json", allProducts.productsNumbers)
    updateReviewsAndRating(allProducts, reviews)

    # Build of all categories as dict of objects of type Product.
    with open('categories.json', 'wb') as output:
        pickle.dump(allProducts, output, pickle.HIGHEST_PROTOCOL)

    # Get all tokens of each category
    with open('categories.json', 'rb') as input:
        categories = pickle.load(input)
        getAllCategoryTokens(categories, 'tokens.txt')
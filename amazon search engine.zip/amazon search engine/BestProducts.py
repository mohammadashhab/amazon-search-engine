import pickle

infile = open('categories.json', 'rb')
categories = pickle.load(infile)



def checkDuplicates(final_list, max):
    for item in final_list:
        if item.number == max.number:
            return False
    return True


def maxElements(lst, N):
    """
    Find the N largest elements in list.
    :param lst: list of objects of type Product.
    :param N: Nth products to find.
    :return: List of N largest products by score.
    """
    final_list = []
    while len(final_list) != N:
        if len(lst) == 0:
            return final_list
        max1 = max(lst, key=lambda item: item.score)
        if checkDuplicates(final_list, max1):
            final_list.append(max1)
        lst.remove(max1)
    return final_list


def isContain(str, lst):
    for i in lst:
        if str in i:
            return i
    return False

def findTheBestProducts(category, lstOfSearchWords):
    """
    Find the best two products fit with uses's search words.
    :param lstOfProducts:
    :param lstOfSearchWords:
    :return:
    """
    productsScore = list()
    lstOfProducts = categories.categories[category]

    for i in lstOfProducts:
        i.score = 0

    for word in lstOfSearchWords:
        for product in lstOfProducts:
            for reviews in product.listOfReviewsAndRatings:
                reviewKey = isContain(word, reviews.reviewScore.keys())
                if reviewKey:
                    product.score += reviews.reviewScore[reviewKey]
                    productsScore.append(product)
    return maxElements(set(productsScore), 6)